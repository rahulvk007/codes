import java.util.*;
import java.math.*;

public class primitiveroots{

    public static boolean isPrimitive(int g, int p){
        ArrayList<BigInteger> temp = new ArrayList<BigInteger>();
        BigInteger bigG = BigInteger.valueOf(g);
        BigInteger bigP = BigInteger.valueOf(p);
        for (int i=1;i<p;i++){
            BigInteger bigTemp = bigG.pow(i).mod(bigP);
            
            if (temp.contains(bigTemp)){
                return false;
            }else{
                temp.add(bigTemp);
            }
        }
        return true;
    }

    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        ArrayList<Integer> array = new ArrayList<Integer>();
        int arr[] = new int[num];

        for (int g=2;g<num;g++){
            if (isPrimitive(g,num)){
                array.add(g);
            }
        }
        System.out.println("Primitive Roots are: "+array);
        
    }
}