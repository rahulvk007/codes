import java.io.*; 
import java.net.*; 
import java.security.*; 
import java.util.Scanner; 
 
public class client { 
    public static boolean verifySignature(byte[] input, byte[] signature, PublicKey key) 
throws Exception { 
        Signature sign = Signature.getInstance("SHA256withRSA"); 
        sign.initVerify(key); 
        sign.update(input); 
        return sign.verify(signature); 
    } 
 
    public static void main(String[] args) { 
        try { 
            Socket socket = new Socket("localhost", 5555); 
            ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream()); 
            PublicKey publicKey = (PublicKey) objectInputStream.readObject(); 
            System.out.print("Enter data: "); 
            Scanner sc = new Scanner(System.in); 
            String data = sc.next(); 
            DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream()); 
            dataOutputStream.writeUTF(data); 
            byte[] signature = (byte[]) objectInputStream.readObject(); 
            System.out.println(data + " : " + new String(signature)); 
            boolean isValid = verifySignature(data.getBytes(), signature, publicKey); 
            System.out.println("Signature verification result: " + isValid); 
 
            socket.close(); 
        } catch (Exception e) { 
            e.printStackTrace(); 
        } 
    } 
}
