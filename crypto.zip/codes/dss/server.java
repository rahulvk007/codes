// import java.io.*; 
// import java.net.*; 
// import java.security.*; 
// import java.util.*; 
 
// public class server { 
//     private static final String SIGNING_ALGORITHM = "SHA256withRSA"; 
 
//     public static byte[] signData(byte[] input, PrivateKey key) throws Exception { 
//         Signature signature = Signature.getInstance(SIGNING_ALGORITHM); 
//         signature.initSign(key); 
//         signature.update(input); 
//         return signature.sign(); 
//     } 
 
//     public static void main(String[] args) { 
//         try { 
//             ServerSocket serverSocket = new ServerSocket(5555); 
//             System.out.println("Server is running..."); 
//             Socket clientSocket = serverSocket.accept(); 
//             System.out.println("Connected to client."); 
//             KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA"); 
//             SecureRandom secureRandom = new SecureRandom(); 
//             keyPairGenerator.initialize(2048, secureRandom); 
//             KeyPair keyPair = keyPairGenerator.generateKeyPair(); 
//             ObjectOutputStream objectOutputStream = new ObjectOutputStream(clientSocket.getOutputStream()); 
//             objectOutputStream.writeObject(keyPair.getPublic()); 
//             DataInputStream dataInputStream = new DataInputStream(clientSocket.getInputStream()); 
//             String inputData = dataInputStream.readUTF(); 
//             byte[] signature = signData(inputData.getBytes(), keyPair.getPrivate()); 
//             objectOutputStream.writeObject(signature); 
//             System.out.println("Data signed and sent to client."); 
 
//             clientSocket.close(); 
//             serverSocket.close(); 
//         } catch (Exception e) { 
//             e.printStackTrace(); 
//         } 
//     } 
// } 

import java.io.*;
import java.util.*;
import java.net.*;
import java.security.*;

public class server{
   public static byte[] signData(byte[] input, PrivateKey key){
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(key);
        signature.update(input);
        return signature.sign();
   }

    public static void main(String args[])throws Exception{
        ServerSocket ss = new ServerSocket(6666);
        Socket s = ss.accept();
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        SecureRandom secureRandom = new SecureRandom();
        keyPairGenerator.initialize(2048,secureRandom);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(s.getOutputStream());
        objectOutputStream.writeObject(keyPair.getPublic());
        DataInputStream dataInputStream = new DataInputStream(s.getInputStream());
        String inputData = dataInputStream.readUTF();
        byte[] signature = signData(inputData.getBytes(),keyPair.getPrivate());
        objectOutputStream.writeObject(signature);
        System.out.println("Data Signed and sent to client");

    }
}