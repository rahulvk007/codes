import java.io.*;
import java.net.*;/**
 * server
 */
public class server {
    public static void main(String args[])throws Exception
    {
        ServerSocket ss = new ServerSocket(6666);
        Socket s = ss.accept();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        DataOutputStream dout = new DataOutputStream(s.getOutputStream());
        DataInputStream din = new DataInputStream(s.getInputStream());
        String str="",str2="";
        while(!str.equals("STOP")){
            str = din.readUTF();
            System.out.println("Client says: "+str);
            str2 = br.readLine();
            dout.writeUTF(str2);
            dout.flush();
        }

    }
}