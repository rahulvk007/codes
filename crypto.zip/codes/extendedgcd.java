import java.util.*;
import java.io.*;

public class extendedgcd{
    public static void main (String args[]){
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();

        int q=0,r=1,t1=0,t2=1;
        int t;
        while (r!=0){
            q = a/b;
            r = a%b;
            t = t1-t2*q;
            a=b;
            b=r;
            t1=t2;
            t2=t;

        }
        System.out.println("GCD is "+a);

    }
}