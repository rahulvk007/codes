import java.io.*;
import java.net.*;/**
 * server
 */
public class server {
    public static void main(String args[])throws Exception
    {
        ServerSocket ss = new ServerSocket(6666);
        Socket s = ss.accept();
        System.out.println("Client Connected");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        DataOutputStream dout = new DataOutputStream(s.getOutputStream());
        DataInputStream din = new DataInputStream(s.getInputStream());
        String str="",str2="";
        int p = 17;
        int alpha=7;
        int xb = 6;
        int yb = (int)Math.pow(alpha,xb)%p;
        System.out.println("Private Key of Server is "+xb);
        System.out.println("Public Key of Server is "+yb);
        String ya = din.readUTF();
        System.out.println("Public Key Received from Client is "+ya);
        dout.writeUTF(String.valueOf(yb));
        dout.flush();
        int y_a = Integer.parseInt(ya);
        int k1 = (int)Math.pow(y_a,xb)%p;
        System.out.println("Secret Key Calculated by Server is "+k1);


    }
}