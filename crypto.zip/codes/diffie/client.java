import java.io.*;
import java.net.*;

public class client{
    public static void main(String args[])throws Exception{
        Socket s = new Socket("localhost",6666);
        System.out.println("Connected to Server");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        DataOutputStream dout = new DataOutputStream(s.getOutputStream());
        DataInputStream din = new DataInputStream(s.getInputStream());
        String str="",str2="";
        int p = 17;
        int alpha = 7; //Assumed (primitive root of p)
        int xa = 5; //Assumed
        System.out.println("Private Key of Client is "+xa);
        int ya = (int)Math.pow(alpha,xa)%p;
        System.out.println("Public Key of Client is "+ya);
        dout.writeUTF(String.valueOf(ya));
        dout.flush();
        String yb = din.readUTF();
        System.out.println("Public Key received from Server is "+yb);
        int y_b = Integer.parseInt(yb);
        int k2 = (int)Math.pow(y_b,xa)%p;
        System.out.println("Secret Key calculated by Client is "+k2);

        

    }
}