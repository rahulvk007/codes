// import java.security.MessageDigest;

// public class md5 {

//     public static void main(String[] args) throws Exception {
//         String message = "Hello, world!";
//         String mac = generateMAC(message);
//         System.out.println("Message: " + message);
//         System.out.println("MAC: " + mac);
//     }

//     public static String generateMAC(String message)throws Exception {
//             MessageDigest md = MessageDigest.getInstance("MD5");
//             byte[] messageBytes = message.getBytes();
//             byte[] digest = md.digest(messageBytes);
//             StringBuilder hexString = new StringBuilder();
//             for (byte b : digest) {
//                 hexString.append(String.format("%02x", b));
//             }
//             return hexString.toString();        
//     }
// }

import java.security.MessageDigest;
import java.util.*;

public class md5{
    public static void main(String args[])throws Exception{
        MessageDigest md = MessageDigest.getInstance("MD5");
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        byte[] messageBytes = s.getBytes();
        byte[] digest = md.digest(messageBytes);
        StringBuilder hexString = new StringBuilder();
        for (byte b: digest){
            hexString.append(String.format("%02x",b));
        }
        System.out.println("MAC: "+hexString.toString());
    }
}