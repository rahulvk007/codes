import java.util.*;
import java.io.*;

public class crt{
    public static void main(String args[]){
        int nums[] = {3,5,7};
        int rems[] = {2,3,2};
        int k = nums.length;
        int x;
        x=1;

        while (true){
            int j;
            
            for(j=0;j<k;j++){
                if (x%nums[j] != rems[j]){
                    break;
                }
            }
            if (j==k){
                System.out.println(x);
                break;
            }else{
                x++;
            }
        }
    }
}