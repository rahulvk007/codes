import java.util.*;
import java.math.*;

public class rsa{

    public static int getGCD(int mod, int num){
        if (mod == 0){
            return num;
        }
        return getGCD(num%mod,mod);
    }

    public static void main(String args[]) throws Exception{
        int d=0,e;
        int prime1 = 13;
        int prime2 = 17;
        int message = 32;
        int primeMul = prime1*prime2;
        int primeMul1 = (prime1-1)*(prime2-1);
        //Public Key
        for (e=2;e<=primeMul1;e++){
            if (getGCD(e, primeMul1)==1){
                break;
            }
        }
        System.out.println("Public Key Generated: "+e);

        //Private Key
        for (int m=0;m<=9;m++){
            int temp = 1 + primeMul1*m;
            if (temp%e==0){
                d = temp/e;
                break;
            }
        }

        System.out.println("Private Key Generated: "+d);

        double cipher;
        cipher = Math.pow(message, e)%primeMul;
        BigInteger d_message;
        System.out.println("Cipher Text: "+cipher);
        BigInteger bigC = BigDecimal.valueOf(cipher).toBigInteger();
        BigInteger pMul = BigInteger.valueOf(primeMul);
        d_message = bigC.pow(d).mod(pMul);
        System.out.println("Plain Text: "+d_message);
    }
}