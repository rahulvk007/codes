import java.util.*;
import java.math.*;

public class caesar{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        String in = sc.nextLine();
        int k = sc.nextInt();
        String enc="";
        char temp;
        int n = in.length();
        for (int i=0;i<n;i++){
            char c = in.charAt(i);
            int asc_c = (int)c;
            if (asc_c>=97){
                temp = (char)(((asc_c-97)+k)%26 +97);
            }else{
                temp = (char)(((asc_c-65)+k)%26 +65);
            }
            enc += temp;
        }
        System.out.println(enc);

    }
}