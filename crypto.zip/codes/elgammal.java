import java.io.*;
import java.util.*;

public class elgammal{
    public static void main(String args[]){
        int p = 17;
        int d = 2;
        int e1 = 3;
        int e2 = (int)Math.pow(e1,d)%p;
        int r = 4;
        int c1 = (int)Math.pow(e1,r)%p;
        int pt = 14;
        int c2 = (int)(pt*Math.pow(e2,r))%p;
        System.out.println("Cipher text c1 is "+c1);
        System.out.println("Cipher text c2 is "+c2);

        int temp = (int)Math.pow(c1,d);
        int temp2;
        for(temp2=1;temp2<p;temp2++){
            if ((temp*temp2)%p == 1){
                break;
            }
        }
        int decrypted = (c2*temp2)%p;
        System.out.println("Decrypted : "+decrypted);
    }
}