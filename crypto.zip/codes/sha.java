import java.util.*;
import java.io.*;
import java.security.MessageDigest;

public class sha{
    public static void main(String args[]) throws Exception{
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        String s = "HelloWorld!";
        byte[] messageBytes = s.getBytes();
        byte[] d = md.digest(messageBytes);
        StringBuilder hexString = new StringBuilder();
        for (byte b: d){
            hexString.append(String.format("%02x",b));
        }
        System.out.print("Digest: "+hexString.toString());
    }
}